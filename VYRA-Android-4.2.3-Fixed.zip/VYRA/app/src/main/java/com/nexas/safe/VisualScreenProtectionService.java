package com.nexas.safe;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.SystemClock;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.WindowManager;
import android.content.pm.ServiceInfo;

import java.io.File;
import java.nio.ByteBuffer;

/**
 * Opt-in, local-only image screening. It starts only with a fresh Android MediaProjection
 * consent result and displays an ongoing notification with a Stop action. Captured frames
 * are held in memory, classified, then recycled; frames are never written or uploaded.
 */
public final class VisualScreenProtectionService extends Service {
    public static final String ACTION_STOP = "com.nexas.safe.action.STOP_VISUAL_SCAN";
    public static final String ACTION_VISUAL_DETECTED = "com.nexas.safe.action.VISUAL_CONTENT_DETECTED";
    public static final String EXTRA_RESULT_CODE = "projection_result_code";
    public static final String EXTRA_RESULT_DATA = "projection_result_data";
    private static final String CHANNEL_ID = "vyra_visual_protection";
    private static final int NOTIFICATION_ID = 4107;
    private static final long FRAME_INTERVAL_MS = 400L;
    private static final long DETECTION_COOLDOWN_MS = 5000L;
    // The detector resizes to 640x640 itself. Capping the capture surface avoids
    // allocating full-resolution bitmaps every frame on memory-constrained phones.
    private static final int MAX_CAPTURE_DIMENSION = 960;

    private MediaProjection projection;
    private VirtualDisplay virtualDisplay;
    private ImageReader imageReader;
    private HandlerThread workerThread;
    private Handler worker;
    private ImageSafetyClassifier classifier;
    private int[] pixelScratch;
    private int captureWidth;
    private int captureHeight;
    private long lastInferenceAt;
    private long lastDetectionAt;
    private boolean cleaned;

    @Override public void onCreate() {
        super.onCreate();
        createNotificationChannel();
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) { stopSelf(); return START_NOT_STICKY; }
        if (ACTION_STOP.equals(intent.getAction())) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (projection != null) return START_NOT_STICKY;
        int resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0);
        Intent resultData;
        if (Build.VERSION.SDK_INT >= 33) resultData = intent.getParcelableExtra(EXTRA_RESULT_DATA, Intent.class);
        else resultData = intent.getParcelableExtra(EXTRA_RESULT_DATA);
        if (resultCode == 0 || resultData == null || !ModelManager.isReady(this)) {
            ProtectionPrefs.prefs(this).edit().putBoolean(ProtectionPrefs.KEY_VISUAL_SCAN_ACTIVE, false)
                    .putString(ProtectionPrefs.KEY_VISUAL_SCAN_ERROR, "Screen permission or on-device model is unavailable.").apply();
            stopSelf();
            return START_NOT_STICKY;
        }

        try {
            Notification notification = buildNotification();
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
            } else {
                startForeground(NOTIFICATION_ID, notification);
            }
            MediaProjectionManager manager = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
            projection = manager.getMediaProjection(resultCode, resultData);
            if (projection == null) throw new IllegalStateException("Android did not create a screen-capture session.");

            workerThread = new HandlerThread("VYRA-Visual-Classifier");
            workerThread.start();
            worker = new Handler(workerThread.getLooper());
            classifier = new ImageSafetyClassifier(ModelManager.modelFile(this));
            startProjectionDisplay();
            ProtectionPrefs.prefs(this).edit().putBoolean(ProtectionPrefs.KEY_VISUAL_SCAN_ACTIVE, true)
                    .remove(ProtectionPrefs.KEY_VISUAL_SCAN_ERROR).apply();
        } catch (Exception ex) {
            ProtectionPrefs.prefs(this).edit().putBoolean(ProtectionPrefs.KEY_VISUAL_SCAN_ACTIVE, false)
                    .putString(ProtectionPrefs.KEY_VISUAL_SCAN_ERROR,
                            ex.getMessage() == null ? "Could not start visual protection." : ex.getMessage()).apply();
            stopSelf();
        }
        return START_NOT_STICKY;
    }

    private void startProjectionDisplay() {
        WindowManager wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        Display display = wm.getDefaultDisplay();
        DisplayMetrics metrics = new DisplayMetrics();
        display.getRealMetrics(metrics);
        int sourceWidth = Math.max(1, metrics.widthPixels);
        int sourceHeight = Math.max(1, metrics.heightPixels);
        float scale = Math.min(1.0f, (float) MAX_CAPTURE_DIMENSION / Math.max(sourceWidth, sourceHeight));
        int width = Math.max(1, Math.round(sourceWidth * scale));
        int height = Math.max(1, Math.round(sourceHeight * scale));
        int density = Math.max(1, metrics.densityDpi);

        captureWidth = width;
        captureHeight = height;
        pixelScratch = new int[width * height];
        imageReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2);
        imageReader.setOnImageAvailableListener(this::onImageAvailable, worker);
        projection.registerCallback(new MediaProjection.Callback() {
            @Override public void onStop() {
                stopSelf();
            }
        }, worker);
        virtualDisplay = projection.createVirtualDisplay("VYRA live visual protection", width, height,
                density, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                imageReader.getSurface(), null, worker);
        if (virtualDisplay == null) throw new IllegalStateException("Android could not create the screen frame stream.");
    }

    private void onImageAvailable(ImageReader reader) {
        Image image = null;
        Bitmap bitmap = null;
        try {
            image = reader.acquireLatestImage();
            if (image == null) return;
            long now = SystemClock.elapsedRealtime();
            if (now - lastInferenceAt < FRAME_INTERVAL_MS) return;
            lastInferenceAt = now;

            // Stop scanning if the user revokes the Accessibility permission while capture is active.
            if (!ProtectionPrefs.isAccessibilityEnabled(this)) {
                stopSelf();
                return;
            }

            // Avoid reclassifying VYRA's own screens and Android system UI.
            String foreground = ProtectionPrefs.prefs(this).getString(ProtectionPrefs.KEY_CURRENT_PACKAGE, "");
            if (getPackageName().equals(foreground) || "com.android.systemui".equals(foreground)
                    || "com.android.permissioncontroller".equals(foreground)) return;

            Image.Plane[] planes = image.getPlanes();
            if (planes == null || planes.length == 0) return;
            Image.Plane plane = planes[0];
            int width = image.getWidth();
            int height = image.getHeight();
            int pixelStride = plane.getPixelStride();
            int rowStride = plane.getRowStride();
            ByteBuffer buffer = plane.getBuffer();
            int requiredBytes = (height - 1) * rowStride + (width - 1) * pixelStride + 4;
            int[] pixels = pixelScratch;
            if (pixels == null || width != captureWidth || height != captureHeight
                    || pixelStride < 4 || buffer.limit() < requiredBytes) return;

            // Copy only visible pixels. ImageReader rows may contain padding, and the final
            // row is not required to include its trailing padding in the ByteBuffer limit.
            // Reuse the fixed-size scratch array to avoid allocating an array every frame.
            for (int y = 0; y < height; y++) {
                int rowStart = y * rowStride;
                int outputStart = y * width;
                for (int x = 0; x < width; x++) {
                    int offset = rowStart + x * pixelStride;
                    int red = buffer.get(offset) & 0xFF;
                    int green = buffer.get(offset + 1) & 0xFF;
                    int blue = buffer.get(offset + 2) & 0xFF;
                    int alpha = buffer.get(offset + 3) & 0xFF;
                    pixels[outputStart + x] = android.graphics.Color.argb(alpha, red, green, blue);
                }
            }
            bitmap = Bitmap.createBitmap(pixels, width, height, Bitmap.Config.ARGB_8888);

            ImageSafetyClassifier.Result result = classifier.classify(bitmap);
            if (result.flagged && now - lastDetectionAt > DETECTION_COOLDOWN_MS) {
                lastDetectionAt = now;
                Intent detected = new Intent(ACTION_VISUAL_DETECTED).setPackage(getPackageName());
                detected.putExtra("confidence", result.confidence);
                sendBroadcast(detected);
            }
        } catch (Exception ignored) {
            // A single malformed frame should not crash the protection service.
        } finally {
            if (bitmap != null && !bitmap.isRecycled()) bitmap.recycle();
            if (image != null) image.close();
        }
    }

    private Notification buildNotification() {
        Intent stopIntent = new Intent(this, VisualScreenProtectionService.class).setAction(ACTION_STOP);
        PendingIntent stopPending = PendingIntent.getService(this, 4108, stopIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Intent openIntent = new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent openPending = PendingIntent.getActivity(this, 4109, openIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder builder = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL_ID) : new Notification.Builder(this);
        return builder.setSmallIcon(android.R.drawable.ic_menu_view)
                .setContentTitle("VYRA visual protection is active")
                .setContentText("Screen frames are checked on-device only. Tap Stop to end capture.")
                .setCategory(Notification.CATEGORY_SERVICE)
                .setVisibility(Notification.VISIBILITY_PRIVATE)
                .setOngoing(true)
                .setContentIntent(openPending)
                .addAction(new Notification.Action.Builder(android.R.drawable.ic_menu_close_clear_cancel,
                        "Stop protection", stopPending).build())
                .build();
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID,
                    "VYRA visual protection", NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("Persistent status for user-started on-device screen scanning.");
            channel.setShowBadge(false);
            ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(channel);
        }
    }

    @Override public void onDestroy() {
        cleanup();
        ProtectionPrefs.prefs(this).edit().putBoolean(ProtectionPrefs.KEY_VISUAL_SCAN_ACTIVE, false).apply();
        if (Build.VERSION.SDK_INT >= 24) stopForeground(STOP_FOREGROUND_REMOVE); else stopForeground(true);
        super.onDestroy();
    }

    private void cleanup() {
        if (cleaned) return;
        cleaned = true;
        // Detach the producer before closing its consumer surface.
        if (virtualDisplay != null) {
            try { virtualDisplay.release(); } catch (RuntimeException ignored) { }
            virtualDisplay = null;
        }
        if (imageReader != null) {
            try { imageReader.setOnImageAvailableListener(null, null); } catch (RuntimeException ignored) { }
            try { imageReader.close(); } catch (RuntimeException ignored) { }
            imageReader = null;
        }
        if (projection != null) {
            MediaProjection current = projection;
            projection = null;
            try { current.stop(); } catch (RuntimeException ignored) { }
        }
        if (classifier != null) { classifier.close(); classifier = null; }
        pixelScratch = null;
        captureWidth = 0;
        captureHeight = 0;
        if (workerThread != null) { workerThread.quitSafely(); workerThread = null; worker = null; }
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
