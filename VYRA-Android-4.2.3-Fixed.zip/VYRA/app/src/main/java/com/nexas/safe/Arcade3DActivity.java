package com.nexas.safe;

import android.app.Activity;
import android.opengl.GLES20;
import android.opengl.GLSurfaceView;
import android.opengl.Matrix;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.util.ArrayList;
import java.util.Random;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

/**
 * Lightweight procedural 3D arcade scenes for VYRA.
 * Uses the Android OpenGL ES 2.0 API; no network, game account or external asset pack is required.
 * This is a playable vertical-slice implementation, not a production game-engine replacement.
 */
public class Arcade3DActivity extends Activity {
    private static final int BG = Color.rgb(7, 10, 19);
    private static final int PANEL = Color.rgb(15, 24, 42);
    private static final int CYAN = Color.rgb(90, 239, 213);
    private static final int PURPLE = Color.rgb(161, 133, 255);
    private static final int GOLD = Color.rgb(255, 194, 87);

    private GLSurfaceView glView;
    private GameRenderer renderer;
    private TextView scoreText;
    private TextView statusText;
    private TextView pauseButton;
    private Button retryButton;
    private final Handler main = new Handler(Looper.getMainLooper());
    private String mode = "runner";
    private float downX, downY;
    private boolean gameFinished;

    private final Runnable uiTicker = new Runnable() {
        @Override public void run() {
            if (renderer != null && scoreText != null) {
                scoreText.setText(renderer.getScoreLabel());
                if (renderer.isFinished() && !gameFinished) {
                    gameFinished = true;
                    statusText.setText(mode.equals("runner") ? "RUN COMPLETE  •  TRY AGAIN" : "COURSE COMPLETE  •  TRY AGAIN");
                    retryButton.setVisibility(View.VISIBLE);
                }
                if (!renderer.isFinished()) {
                    statusText.setText(renderer.getHint());
                    retryButton.setVisibility(View.GONE);
                }
            }
            main.postDelayed(this, 250L);
        }
    };

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        mode = getIntent().getStringExtra("game_mode");
        if (mode == null) mode = "runner";
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(BG);
        glView = new GLSurfaceView(this);
        glView.setEGLContextClientVersion(2);
        glView.setEGLConfigChooser(8, 8, 8, 8, 16, 0);
        glView.setPreserveEGLContextOnPause(true);
        renderer = new GameRenderer(mode, this::onRendererFinished);
        glView.setRenderer(renderer);
        glView.setRenderMode(GLSurfaceView.RENDERMODE_CONTINUOUSLY);
        root.addView(glView, new FrameLayout.LayoutParams(-1, -1));

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(dp(14), dp(12), dp(14), dp(12));
        top.setBackground(gradient(new int[]{0xEE0B1325, 0xAA0B1325}, 20));
        TextView back = chip("‹", 26, Color.WHITE);
        top.addView(back, new LinearLayout.LayoutParams(dp(44), dp(44)));
        back.setOnClickListener(v -> finish());
        LinearLayout titleStack = new LinearLayout(this);
        titleStack.setOrientation(LinearLayout.VERTICAL);
        TextView title = text(mode.equals("runner") ? "TEMPLE SPRINT 3D" : "ORBIT ROLL 3D", 13, Color.WHITE, true);
        TextView overline = text("VYRA ARCADE  /  OFFLINE MODE", 8, CYAN, true);
        overline.setLetterSpacing(0.12f);
        titleStack.addView(title);
        titleStack.addView(overline);
        LinearLayout.LayoutParams titleLp = new LinearLayout.LayoutParams(0, -2, 1f);
        titleLp.leftMargin = dp(8);
        top.addView(titleStack, titleLp);
        scoreText = chip(mode.equals("runner") ? "0 M" : "0 PTS", 12, GOLD);
        top.addView(scoreText, new LinearLayout.LayoutParams(dp(76), dp(42)));
        pauseButton = chip("Ⅱ", 18, Color.WHITE);
        LinearLayout.LayoutParams pauseLp = new LinearLayout.LayoutParams(dp(44), dp(44));
        pauseLp.leftMargin = dp(7);
        top.addView(pauseButton, pauseLp);
        pauseButton.setOnClickListener(v -> glView.queueEvent(() -> {
            boolean paused = renderer.togglePause();
            main.post(() -> {
                if (isFinishing() || pauseButton == null || statusText == null) return;
                pauseButton.setText(paused ? "▶" : "Ⅱ");
                statusText.setText(paused ? "PAUSED" : renderer.getHint());
            });
        }));
        FrameLayout.LayoutParams topLp = new FrameLayout.LayoutParams(-1, -2, Gravity.TOP);
        topLp.setMargins(dp(10), dp(12), dp(10), 0);
        root.addView(top, topLp);

        LinearLayout bottom = new LinearLayout(this);
        bottom.setOrientation(LinearLayout.VERTICAL);
        bottom.setGravity(Gravity.CENTER);
        bottom.setPadding(dp(16), dp(12), dp(16), dp(14));
        bottom.setBackground(gradient(new int[]{0xAA0B1325, 0xEE0B1325}, 20));
        statusText = text(mode.equals("runner") ? "SWIPE LEFT / RIGHT  •  UP TO JUMP  •  DOWN TO SLIDE" : "SWIPE LEFT / RIGHT TO STEER  •  COLLECT LIGHT ORBS", 10, Color.WHITE, true);
        statusText.setGravity(Gravity.CENTER);
        bottom.addView(statusText, new LinearLayout.LayoutParams(-1, -2));
        retryButton = new Button(this);
        retryButton.setText("PLAY AGAIN");
        retryButton.setTextColor(Color.WHITE);
        retryButton.setTextSize(11);
        retryButton.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        retryButton.setAllCaps(false);
        retryButton.setBackground(gradient(new int[]{PURPLE, CYAN}, 16));
        retryButton.setVisibility(View.GONE);
        LinearLayout.LayoutParams retryLp = new LinearLayout.LayoutParams(-1, dp(45));
        retryLp.topMargin = dp(9);
        bottom.addView(retryButton, retryLp);
        retryButton.setOnClickListener(v -> {
            gameFinished = false;
            retryButton.setVisibility(View.GONE);
            glView.queueEvent(() -> renderer.resetGame());
        });
        FrameLayout.LayoutParams bottomLp = new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM);
        bottomLp.setMargins(dp(10), 0, dp(10), dp(12));
        root.addView(bottom, bottomLp);

        glView.setOnTouchListener((v, event) -> handleGameTouch(event, v.getWidth(), v.getHeight()));
        setContentView(root);
        main.post(uiTicker);
    }

    private boolean handleGameTouch(MotionEvent e, int width, int height) {
        if (renderer == null || width <= 0 || height <= 0) return true;
        if (e.getAction() == MotionEvent.ACTION_DOWN) {
            downX = e.getX(); downY = e.getY();
            return true;
        }
        if (e.getAction() == MotionEvent.ACTION_UP) {
            float dx = e.getX() - downX, dy = e.getY() - downY;
            if (Math.abs(dx) > Math.abs(dy) && Math.abs(dx) > dp(35)) {
                int direction = dx < 0 ? -1 : 1;
                glView.queueEvent(() -> renderer.moveLane(direction));
            } else if (mode.equals("runner") && Math.abs(dy) > dp(35)) {
                if (dy < 0) glView.queueEvent(() -> renderer.jump());
                else glView.queueEvent(() -> renderer.slide());
            }
            return true;
        }
        return true;
    }

    private void onRendererFinished() {
        main.post(() -> {
            if (isFinishing() || isDestroyed()) return;
            gameFinished = true;
            if (statusText != null) statusText.setText(mode.equals("runner")
                    ? "RUN COMPLETE  •  TRY AGAIN" : "COURSE COMPLETE  •  TRY AGAIN");
            if (retryButton != null) retryButton.setVisibility(View.VISIBLE);
        });
    }

    @Override protected void onResume() {
        super.onResume();
        if (glView != null) glView.onResume();
        main.removeCallbacks(uiTicker);
        main.post(uiTicker);
    }
    @Override protected void onPause() { main.removeCallbacks(uiTicker); if (glView != null) glView.onPause(); super.onPause(); }
    @Override protected void onDestroy() {
        main.removeCallbacks(uiTicker);
        if (glView != null) {
            glView.onPause();
            glView.setOnTouchListener(null);
        }
        renderer = null;
        glView = null;
        super.onDestroy();
    }

    @Override public void onBackPressed() { finish(); }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(value); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        return t;
    }
    private TextView chip(String value, int size, int color) {
        TextView t = text(value, size, color, true); t.setGravity(Gravity.CENTER);
        t.setBackground(gradient(new int[]{0xE51A2943, 0xE5101A2E}, 15));
        return t;
    }
    private GradientDrawable gradient(int[] colors, int radius) {
        GradientDrawable d = new GradientDrawable(GradientDrawable.Orientation.TL_BR, colors);
        d.setCornerRadius(dp(radius)); d.setStroke(dp(1), 0x664C6A91); return d;
    }
    private int dp(int value) { return Math.round(value * getResources().getDisplayMetrics().density); }

    private static final class GameRenderer implements GLSurfaceView.Renderer {
        private final String mode;
        private final Runnable finishedCallback;
        private final Random random = new Random();
        private final float[] projection = new float[16], view = new float[16], vp = new float[16];
        private final float[] model = new float[16], mvp = new float[16];
        private FloatBuffer cubeBuffer, sphereBuffer;
        private int cubeCount, sphereCount, program;
        private int aPosition, aNormal, uMvp, uModel, uColor;
        private long lastFrame;
        private float elapsed, spawnTimer, distance, speed = 7.2f;
        private int score, coins, lives = 3, lane = 1;
        private float jumpTimer, slideTimer;
        private volatile boolean paused, finished;
        private volatile String scoreLabel = "0 M";
        private volatile String hint;
        private final ArrayList<WorldItem> items = new ArrayList<>();
        private boolean callbackSent;

        GameRenderer(String mode, Runnable finishedCallback) {
            this.mode = mode;
            this.finishedCallback = finishedCallback;
            this.hint = mode.equals("runner") ? "DODGE THE RUINS  •  COLLECT THE LIGHTS" : "STEER THE ORB  •  COLLECT THE LIGHTS";
        }

        @Override public void onSurfaceCreated(GL10 gl, EGLConfig config) {
            GLES20.glEnable(GLES20.GL_DEPTH_TEST);
            GLES20.glDisable(GLES20.GL_CULL_FACE);
            GLES20.glClearColor(0.025f, 0.045f, 0.095f, 1f);
            program = buildProgram();
            aPosition = GLES20.glGetAttribLocation(program, "aPosition");
            aNormal = GLES20.glGetAttribLocation(program, "aNormal");
            uMvp = GLES20.glGetUniformLocation(program, "uMVP");
            uModel = GLES20.glGetUniformLocation(program, "uModel");
            uColor = GLES20.glGetUniformLocation(program, "uColor");
            cubeBuffer = makeCube(); cubeCount = 36;
            sphereBuffer = makeSphere(18, 24); sphereCount = 18 * 24 * 6;
            lastFrame = System.nanoTime();
        }

        @Override public void onSurfaceChanged(GL10 gl, int width, int height) {
            GLES20.glViewport(0, 0, width, height);
            Matrix.perspectiveM(projection, 0, 54f, (float) width / Math.max(1, height), 0.1f, 100f);
        }

        @Override public void onDrawFrame(GL10 gl) {
            long now = System.nanoTime();
            float dt = Math.min(0.04f, (now - lastFrame) / 1_000_000_000f);
            lastFrame = now;
            if (!paused && !finished) update(dt);
            GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT | GLES20.GL_DEPTH_BUFFER_BIT);
            if (mode.equals("runner")) drawRunner(); else drawOrbitRoll();
        }

        private void update(float dt) {
            elapsed += dt;
            if (mode.equals("runner")) {
                distance += speed * dt;
                speed = Math.min(13f, 7.2f + distance / 220f);
                spawnTimer -= dt;
                if (spawnTimer <= 0) {
                    int spawnLane = random.nextInt(3);
                    items.add(new WorldItem(spawnLane, -22f, random.nextFloat() > 0.35f));
                    spawnTimer = Math.max(0.58f, 1.05f - distance / 1500f) + random.nextFloat() * 0.3f;
                }
                if (jumpTimer > 0) jumpTimer = Math.max(0, jumpTimer - dt);
                if (slideTimer > 0) slideTimer = Math.max(0, slideTimer - dt);
                for (int i = items.size() - 1; i >= 0; i--) {
                    WorldItem item = items.get(i);
                    item.z += speed * dt;
                    if (item.z > 0.7f && item.z < 1.35f && !item.checked && item.lane == lane) {
                        item.checked = true;
                        if (item.coin) coins++;
                        else if (jumpTimer < 0.12f && slideTimer < 0.12f) lives--;
                    }
                    if (item.z > 2.4f || (item.checked && item.coin)) items.remove(i);
                }
                score = (int) (distance * 3f) + coins * 20;
                scoreLabel = ((int) distance) + " M  •  " + coins + " ✦";
                if (lives <= 0) finish("Run ended");
                if (distance > 1600) finish("Run cleared");
            } else {
                updateOrbitRoll(dt);
            }
        }

        private void drawRunner() {
            Matrix.setLookAtM(view, 0, 0f, 4.3f, 8.4f, 0f, 0.45f, -5.5f, 0f, 1f, 0f);
            Matrix.multiplyMM(vp, 0, projection, 0, view, 0);
            drawCube(0f, -0.18f, -8f, 4.8f, 0.25f, 17f, new float[]{0.07f,0.12f,0.20f,1f}, 0f);
            for (int z = 0; z < 9; z++) {
                float zz = -18f + z * 2.8f + (distance % 2.8f);
                drawCube(-0.77f, -0.035f, zz, 0.035f, 0.014f, 0.95f, new float[]{0.13f,0.72f,0.75f,1f}, 0f);
                drawCube(0.77f, -0.035f, zz, 0.035f, 0.014f, 0.95f, new float[]{0.13f,0.72f,0.75f,1f}, 0f);
            }
            // distant illuminated temple pillars and canyon walls
            for (int i = 0; i < 7; i++) {
                float z = -18f + i * 3.2f + (distance % 3.2f);
                drawCube(-2.8f, 1.25f, z, 0.28f, 1.55f, 0.34f, new float[]{0.13f,0.20f,0.30f,1f}, 0f);
                drawCube(2.8f, 1.25f, z, 0.28f, 1.55f, 0.34f, new float[]{0.13f,0.20f,0.30f,1f}, 0f);
                drawCube(-2.8f, 2.95f, z, 0.75f, 0.12f, 0.42f, new float[]{0.25f,0.33f,0.45f,1f}, 0f);
                drawCube(2.8f, 2.95f, z, 0.75f, 0.12f, 0.42f, new float[]{0.25f,0.33f,0.45f,1f}, 0f);
            }
            float jumpY = jumpTimer > 0 ? (float)Math.sin((0.72f-jumpTimer)/0.72f*Math.PI) * 1.5f : 0f;
            float playerX = (lane - 1) * 1.35f;
            float playerHeight = slideTimer > 0 ? 0.48f : 0.9f;
            drawCube(playerX, 0.45f + jumpY, 0.68f, 0.55f, playerHeight, 0.42f, new float[]{0.18f,0.83f,0.88f,1f}, (float)Math.sin(elapsed*8f)*8f);
            drawSphere(playerX, 1.12f + jumpY, 0.68f, 0.34f, new float[]{0.86f,0.90f,1f,1f});
            drawCube(playerX-0.23f, 0.05f+jumpY, 0.72f, 0.16f, 0.34f, 0.18f, new float[]{0.52f,0.41f,0.95f,1f}, 0f);
            drawCube(playerX+0.23f, 0.05f+jumpY, 0.72f, 0.16f, 0.34f, 0.18f, new float[]{0.52f,0.41f,0.95f,1f}, 0f);
            for (WorldItem item : items) {
                float x = (item.lane - 1) * 1.35f;
                if (item.coin) {
                    drawSphere(x, 0.72f, item.z, 0.23f, new float[]{1f,0.72f,0.19f,1f});
                    drawSphere(x, 0.72f, item.z+0.035f, 0.105f, new float[]{1f,0.9f,0.48f,1f});
                } else {
                    drawCube(x, 0.55f, item.z, 0.55f, 0.58f, 0.44f, new float[]{0.83f,0.31f,0.42f,1f}, 0f);
                    drawCube(x, 1.16f, item.z, 0.61f, 0.10f, 0.49f, new float[]{0.98f,0.54f,0.45f,1f}, 0f);
                }
            }
            for (int i=0;i<lives;i++) drawSphere(-1.45f+i*0.42f, 3.3f, 0f, 0.12f, new float[]{0.98f,0.30f,0.45f,1f});
        }

        private void drawOrbitRoll() {
            Matrix.setLookAtM(view, 0, 0f, 3.7f, 8.0f, 0f, 0.45f, -5.5f, 0f, 1f, 0f);
            Matrix.multiplyMM(vp, 0, projection, 0, view, 0);
            drawCube(0f, -0.18f, -8f, 4.2f, 0.25f, 18f, new float[]{0.07f,0.12f,0.20f,1f}, 0f);
            for (int z = 0; z < 10; z++) {
                float zz = -20f + z * 2.7f + (distance % 2.7f);
                drawCube(-1.88f, -0.02f, zz, 0.055f, 0.025f, 0.85f, new float[]{0.14f,0.58f,0.72f,1f}, 0f);
                drawCube(1.88f, -0.02f, zz, 0.055f, 0.025f, 0.85f, new float[]{0.14f,0.58f,0.72f,1f}, 0f);
                drawCube(0f, -0.02f, zz, 0.018f, 0.015f, 0.68f, new float[]{0.12f,0.34f,0.48f,1f}, 0f);
            }
            for (int i = 0; i < 7; i++) {
                float z = -18f + i * 3.2f + (distance % 3.2f);
                drawCube(-2.55f, 1.0f, z, 0.20f, 1.15f, 0.24f, new float[]{0.12f,0.23f,0.36f,1f}, 0f);
                drawCube(2.55f, 1.0f, z, 0.20f, 1.15f, 0.24f, new float[]{0.12f,0.23f,0.36f,1f}, 0f);
            }
            float orbX = (lane - 1) * 1.35f;
            float pulse = 0.40f + (float)Math.sin(elapsed * 5f) * 0.025f;
            drawSphere(orbX, 0.62f, 0.72f, pulse, new float[]{0.24f,0.86f,0.91f,1f});
            drawSphere(orbX - 0.10f, 0.77f, 0.94f, 0.10f, new float[]{0.92f,1f,1f,1f});
            for (WorldItem item : items) {
                float x = (item.lane - 1) * 1.35f;
                if (item.coin) {
                    drawSphere(x, 0.70f, item.z, 0.22f, new float[]{1f,0.76f,0.22f,1f});
                    drawSphere(x, 0.70f, item.z + 0.025f, 0.10f, new float[]{1f,0.94f,0.63f,1f});
                } else {
                    drawCube(x, 0.52f, item.z, 0.48f, 0.52f, 0.42f, new float[]{0.55f,0.42f,0.88f,1f}, (float)Math.sin(elapsed * 2f) * 5f);
                    drawCube(x, 1.06f, item.z, 0.50f, 0.08f, 0.44f, new float[]{0.34f,0.74f,0.83f,1f}, 0f);
                }
            }
            for (int i = 0; i < lives; i++) drawSphere(-1.35f + i * 0.40f, 3.0f, 0f, 0.11f, new float[]{0.98f,0.48f,0.67f,1f});
        }

        private void updateOrbitRoll(float dt) {
            distance += speed * dt;
            speed = Math.min(10.5f, 5.5f + distance / 280f);
            spawnTimer -= dt;
            if (spawnTimer <= 0f) {
                int spawnLane = random.nextInt(3);
                items.add(new WorldItem(spawnLane, -22f, random.nextFloat() > 0.38f));
                spawnTimer = Math.max(0.62f, 1.0f - distance / 1800f) + random.nextFloat() * 0.35f;
            }
            for (int i = items.size() - 1; i >= 0; i--) {
                WorldItem item = items.get(i);
                item.z += speed * dt;
                if (item.z > 0.72f && item.z < 1.35f && !item.checked && item.lane == lane) {
                    item.checked = true;
                    if (item.coin) coins++;
                    else lives--;
                }
                if (item.z > 2.4f || item.checked) items.remove(i);
            }
            score = (int)(distance * 2.2f) + coins * 25;
            scoreLabel = ((int)distance) + " M  •  " + coins + " ✦";
            if (lives <= 0) finish("Orb run ended");
            if (distance > 1250f) finish("Orb course cleared");
        }

        private void drawCube(float x,float y,float z,float sx,float sy,float sz,float[] color,float rotationY) {
            drawMesh(cubeBuffer,cubeCount,x,y,z,sx,sy,sz,color,rotationY);
        }
        private void drawSphere(float x,float y,float z,float radius,float[] color) {
            drawMesh(sphereBuffer,sphereCount,x,y,z,radius,radius,radius,color,0f);
        }
        private void drawMesh(FloatBuffer buffer,int count,float x,float y,float z,float sx,float sy,float sz,float[] color,float rotationY) {
            Matrix.setIdentityM(model,0);
            Matrix.translateM(model,0,x,y,z);
            Matrix.rotateM(model,0,rotationY,0,1,0);
            Matrix.scaleM(model,0,sx,sy,sz);
            Matrix.multiplyMM(mvp,0,vp,0,model,0);
            GLES20.glUseProgram(program);
            GLES20.glUniformMatrix4fv(uMvp,1,false,mvp,0);
            GLES20.glUniformMatrix4fv(uModel,1,false,model,0);
            GLES20.glUniform4fv(uColor,1,color,0);
            buffer.position(0);
            GLES20.glEnableVertexAttribArray(aPosition);
            GLES20.glEnableVertexAttribArray(aNormal);
            GLES20.glVertexAttribPointer(aPosition,3,GLES20.GL_FLOAT,false,24,buffer);
            buffer.position(3);
            GLES20.glVertexAttribPointer(aNormal,3,GLES20.GL_FLOAT,false,24,buffer);
            GLES20.glDrawArrays(GLES20.GL_TRIANGLES,0,count);
            GLES20.glDisableVertexAttribArray(aPosition);
            GLES20.glDisableVertexAttribArray(aNormal);
        }

        void moveLane(int direction) {
            if (!paused && !finished) {
                lane = Math.max(0, Math.min(2, lane + direction));
                if (!mode.equals("runner")) hint = "LANE " + (lane + 1) + "  •  KEEP ROLLING";
            }
        }
        void jump() { if (!paused && !finished && jumpTimer <= 0) { jumpTimer=0.72f; slideTimer=0; } }
        void slide() { if (!paused && !finished && slideTimer <= 0) { slideTimer=0.66f; jumpTimer=0; } }
        boolean togglePause() { paused=!paused; return paused; }
        void resetGame() {
            paused=false; finished=false; callbackSent=false; elapsed=0; score=0;
            distance=0; spawnTimer=0.5f; items.clear(); lives=3; lane=1;
            coins=0; speed=mode.equals("runner") ? 7.2f : 5.5f;
            jumpTimer=0; slideTimer=0; scoreLabel=mode.equals("runner") ? "0 M" : "0 M  •  0 ✦";
            hint=mode.equals("runner") ? "DODGE THE RUINS  •  COLLECT THE LIGHTS" : "STEER THE ORB  •  COLLECT THE LIGHTS";
        }
        private void finish(String ignored) { finished=true; paused=false; if(!callbackSent){callbackSent=true;if(finishedCallback!=null)finishedCallback.run();} }
        boolean isFinished() { return finished; }
        String getScoreLabel() { return scoreLabel; }
        String getHint() { return hint; }
        private static final class WorldItem { int lane; float z; boolean coin,checked; WorldItem(int lane,float z,boolean coin){this.lane=lane;this.z=z;this.coin=coin;} }

        private int buildProgram() {
            String vertex = "attribute vec3 aPosition; attribute vec3 aNormal; uniform mat4 uMVP; uniform mat4 uModel; varying float vLight; void main(){ vec3 n=normalize(mat3(uModel)*aNormal); vec3 l=normalize(vec3(-0.35,0.82,0.48)); vLight=0.35+0.65*max(dot(n,l),0.0); gl_Position=uMVP*vec4(aPosition,1.0); }";
            String fragment = "precision mediump float; uniform vec4 uColor; varying float vLight; void main(){ gl_FragColor=vec4(uColor.rgb*vLight,uColor.a); }";
            int vs=compileShader(GLES20.GL_VERTEX_SHADER,vertex), fs=compileShader(GLES20.GL_FRAGMENT_SHADER,fragment);
            int p=GLES20.glCreateProgram(); GLES20.glAttachShader(p,vs); GLES20.glAttachShader(p,fs); GLES20.glLinkProgram(p);
            int[] status=new int[1]; GLES20.glGetProgramiv(p,GLES20.GL_LINK_STATUS,status,0);
            if(status[0]==0) throw new RuntimeException("OpenGL shader link failed: "+GLES20.glGetProgramInfoLog(p));
            GLES20.glDeleteShader(vs); GLES20.glDeleteShader(fs); return p;
        }
        private int compileShader(int type,String source) {
            int s=GLES20.glCreateShader(type); GLES20.glShaderSource(s,source); GLES20.glCompileShader(s);
            int[] status=new int[1]; GLES20.glGetShaderiv(s,GLES20.GL_COMPILE_STATUS,status,0);
            if(status[0]==0) throw new RuntimeException("OpenGL shader compile failed: "+GLES20.glGetShaderInfoLog(s));
            return s;
        }
        private FloatBuffer makeCube() {
            float[][] faces={
                {-0.5f,-0.5f,0.5f, 0.5f,-0.5f,0.5f, 0.5f,0.5f,0.5f, -0.5f,0.5f,0.5f, 0f,0f,1f},
                {0.5f,-0.5f,-0.5f, -0.5f,-0.5f,-0.5f, -0.5f,0.5f,-0.5f, 0.5f,0.5f,-0.5f, 0f,0f,-1f},
                {-0.5f,0.5f,0.5f, 0.5f,0.5f,0.5f, 0.5f,0.5f,-0.5f, -0.5f,0.5f,-0.5f, 0f,1f,0f},
                {-0.5f,-0.5f,-0.5f, 0.5f,-0.5f,-0.5f, 0.5f,-0.5f,0.5f, -0.5f,-0.5f,0.5f, 0f,-1f,0f},
                {0.5f,-0.5f,0.5f, 0.5f,-0.5f,-0.5f, 0.5f,0.5f,-0.5f, 0.5f,0.5f,0.5f, 1f,0f,0f},
                {-0.5f,-0.5f,-0.5f, -0.5f,-0.5f,0.5f, -0.5f,0.5f,0.5f, -0.5f,0.5f,-0.5f, -1f,0f,0f}
            };
            float[] out=new float[36*6]; int k=0;
            for(float[] f:faces){int[] order={0,1,2,0,2,3};for(int idx:order){int p=idx*3;out[k++]=f[p];out[k++]=f[p+1];out[k++]=f[p+2];out[k++]=f[12];out[k++]=f[13];out[k++]=f[14];}}
            return buffer(out);
        }
        private FloatBuffer makeSphere(int rings,int sectors) {
            float[] out=new float[rings*sectors*6*6]; int k=0;
            for(int r=0;r<rings;r++) for(int s=0;s<sectors;s++) {
                float v0=(float)r/rings, v1=(float)(r+1)/rings;
                float u0=(float)s/sectors, u1=(float)(s+1)/sectors;
                float[] a=spherePoint(v0,u0), b=spherePoint(v1,u0), c=spherePoint(v1,u1), d=spherePoint(v0,u1);
                float[][] tri={a,b,c,a,c,d};
                for(float[] q:tri) for(int j=0;j<3;j++){out[k++]=q[j];out[k++]=q[j];out[k++]=q[j];}
            }
            return buffer(out);
        }
        private float[] spherePoint(float v,float u){double lat=(v-0.5)*Math.PI,lon=u*2*Math.PI;float x=(float)(Math.cos(lat)*Math.cos(lon)),y=(float)Math.sin(lat),z=(float)(Math.cos(lat)*Math.sin(lon));return new float[]{x,y,z};}
        private FloatBuffer buffer(float[] data){ByteBuffer bb=ByteBuffer.allocateDirect(data.length*4).order(ByteOrder.nativeOrder());FloatBuffer fb=bb.asFloatBuffer();fb.put(data).position(0);return fb;}
    }
}
