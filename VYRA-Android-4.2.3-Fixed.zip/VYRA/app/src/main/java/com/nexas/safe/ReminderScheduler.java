package com.nexas.safe;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import java.util.Calendar;

final class ReminderScheduler {
    static final String ACTION_DAILY_SIGNAL = "com.nexas.safe.DAILY_SIGNAL";
    private static final int REQUEST_CODE = 7301;
    private ReminderScheduler() { }

    static void schedule(Context context, int hour, int minute) {
        ProtectionPrefs.prefs(context).edit()
                .putInt(ProtectionPrefs.KEY_REMINDER_HOUR, hour)
                .putInt(ProtectionPrefs.KEY_REMINDER_MINUTE, minute)
                .putBoolean(ProtectionPrefs.KEY_REMINDER_ENABLED, true)
                .apply();
        scheduleNext(context);
    }

    static void scheduleNext(Context context) {
        if (!ProtectionPrefs.prefs(context).getBoolean(ProtectionPrefs.KEY_REMINDER_ENABLED, false)) return;
        int hour = ProtectionPrefs.prefs(context).getInt(ProtectionPrefs.KEY_REMINDER_HOUR, 20);
        int minute = ProtectionPrefs.prefs(context).getInt(ProtectionPrefs.KEY_REMINDER_MINUTE, 0);
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.HOUR_OF_DAY, hour);
        calendar.set(Calendar.MINUTE, minute);
        calendar.set(Calendar.SECOND, 0);
        calendar.set(Calendar.MILLISECOND, 0);
        if (calendar.getTimeInMillis() <= System.currentTimeMillis()) calendar.add(Calendar.DAY_OF_YEAR, 1);

        AlarmManager manager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        PendingIntent pending = pendingIntent(context);
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && manager.canScheduleExactAlarms()) {
                manager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(), pending);
            } else {
                manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(), pending);
            }
        } catch (SecurityException ex) {
            manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(), pending);
        }
    }

    static void cancel(Context context) {
        ProtectionPrefs.prefs(context).edit().putBoolean(ProtectionPrefs.KEY_REMINDER_ENABLED, false).apply();
        ((AlarmManager) context.getSystemService(Context.ALARM_SERVICE)).cancel(pendingIntent(context));
    }

    private static PendingIntent pendingIntent(Context context) {
        Intent intent = new Intent(context, AlarmReceiver.class).setAction(ACTION_DAILY_SIGNAL);
        return PendingIntent.getBroadcast(context, REQUEST_CODE, intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }
}
