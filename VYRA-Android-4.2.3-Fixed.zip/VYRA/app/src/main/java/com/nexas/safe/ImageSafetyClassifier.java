package com.nexas.safe;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import org.tensorflow.lite.DataType;
import org.tensorflow.lite.Interpreter;

import java.io.Closeable;
import java.io.File;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/** Local visual content detector. It never uploads or stores the image being checked. */
final class ImageSafetyClassifier implements Closeable {
    static final int INPUT_SIZE = 640;
    static final float BLOCK_THRESHOLD = 0.55f;

    // YOLO output channels 0..3 are boxes; class scores start at channel 4.
    // Sensitive NudeNet class IDs: 2, 3, 4, 5, 6 and 14.
    private static final int[] SENSITIVE_OUTPUT_CHANNELS = {6, 7, 8, 9, 10, 18};
    private static final int EXPECTED_OUTPUT_CHANNELS = 22;
    private static final int EXPECTED_ANCHORS = 8400;

    private final Interpreter interpreter;
    private final Bitmap letterboxedBitmap;
    private final Canvas bitmapCanvas;
    private final int outputChannels;
    private final int anchors;
    private final ByteBuffer inputBuffer;
    private final int[] pixelBuffer;
    private final float[][][] outputBuffer;
    private final Paint resizePaint = new Paint(Paint.FILTER_BITMAP_FLAG | Paint.ANTI_ALIAS_FLAG);
    private final RectF destination = new RectF();
    private boolean closed;

    static final class Result {
        final boolean flagged;
        final float confidence;

        Result(boolean flagged, float confidence) {
            this.flagged = flagged;
            this.confidence = confidence;
        }
    }

    ImageSafetyClassifier(File model) throws IOException {
        if (model == null || !model.isFile() || model.length() < 5_000_000L) {
            throw new IOException("AI model is missing or incomplete");
        }

        Interpreter opened = null;
        Bitmap bitmap = null;
        Canvas canvas = null;
        ByteBuffer input = null;
        int[] pixels = null;
        float[][][] output = null;
        int channels = 0;
        int anchorCount = 0;
        try {
            Interpreter.Options options = new Interpreter.Options().setNumThreads(2);
            opened = new Interpreter(model, options);

            if (opened.getInputTensorCount() != 1 || opened.getOutputTensorCount() != 1) {
                throw new IOException("Unsupported AI model: expected one input tensor and one output tensor");
            }

            int[] inputShape = opened.getInputTensor(0).shape();
            int[] outputShape = opened.getOutputTensor(0).shape();
            boolean validInput = inputShape.length == 4
                    && inputShape[0] == 1 && inputShape[1] == INPUT_SIZE
                    && inputShape[2] == INPUT_SIZE && inputShape[3] == 3
                    && opened.getInputTensor(0).dataType() == DataType.FLOAT32;
            boolean validOutput = outputShape.length == 3
                    && outputShape[0] == 1
                    && outputShape[1] == EXPECTED_OUTPUT_CHANNELS
                    && outputShape[2] == EXPECTED_ANCHORS
                    && opened.getOutputTensor(0).dataType() == DataType.FLOAT32;
            if (!validInput || !validOutput) {
                throw new IOException("Unsupported AI model tensor layout. Expected float32 [1,640,640,3] input and [1,22,8400] output.");
            }

            channels = outputShape[1];
            anchorCount = outputShape[2];
            bitmap = Bitmap.createBitmap(INPUT_SIZE, INPUT_SIZE, Bitmap.Config.ARGB_8888);
            canvas = new Canvas(bitmap);
            input = ByteBuffer.allocateDirect(INPUT_SIZE * INPUT_SIZE * 3 * 4)
                    .order(ByteOrder.nativeOrder());
            pixels = new int[INPUT_SIZE * INPUT_SIZE];
            output = new float[1][channels][anchorCount];
        } catch (IOException ex) {
            recycle(bitmap);
            closeInterpreter(opened);
            throw ex;
        } catch (RuntimeException | OutOfMemoryError ex) {
            recycle(bitmap);
            closeInterpreter(opened);
            throw new IOException("Could not initialise the on-device AI model or its image buffers", ex);
        }

        interpreter = opened;
        letterboxedBitmap = bitmap;
        bitmapCanvas = canvas;
        outputChannels = channels;
        anchors = anchorCount;
        inputBuffer = input;
        pixelBuffer = pixels;
        outputBuffer = output;
    }

    synchronized Result classify(Bitmap source) {
        if (closed || source == null || source.isRecycled()
                || source.getWidth() <= 0 || source.getHeight() <= 0) {
            return new Result(false, 0f);
        }

        bitmapCanvas.drawColor(Color.rgb(114, 114, 114));
        float scale = Math.min((float) INPUT_SIZE / source.getWidth(),
                (float) INPUT_SIZE / source.getHeight());
        float width = source.getWidth() * scale;
        float height = source.getHeight() * scale;
        float left = (INPUT_SIZE - width) / 2f;
        float top = (INPUT_SIZE - height) / 2f;
        destination.set(left, top, left + width, top + height);
        bitmapCanvas.drawBitmap(source, null, destination, resizePaint);
        letterboxedBitmap.getPixels(pixelBuffer, 0, INPUT_SIZE, 0, 0, INPUT_SIZE, INPUT_SIZE);

        inputBuffer.clear();
        for (int pixel : pixelBuffer) {
            inputBuffer.putFloat(((pixel >> 16) & 0xFF) / 255.0f);
            inputBuffer.putFloat(((pixel >> 8) & 0xFF) / 255.0f);
            inputBuffer.putFloat((pixel & 0xFF) / 255.0f);
        }
        inputBuffer.flip();
        interpreter.run(inputBuffer, outputBuffer);

        float maximum = 0f;
        for (int outputChannel : SENSITIVE_OUTPUT_CHANNELS) {
            for (int anchor = 0; anchor < anchors; anchor++) {
                float score = outputBuffer[0][outputChannel][anchor];
                if (Float.isFinite(score) && score > maximum) maximum = score;
            }
        }
        return new Result(maximum >= BLOCK_THRESHOLD, maximum);
    }

    @Override public synchronized void close() {
        if (closed) return;
        closed = true;
        closeInterpreter(interpreter);
        recycle(letterboxedBitmap);
    }

    private static void closeInterpreter(Interpreter instance) {
        if (instance == null) return;
        try { instance.close(); } catch (RuntimeException ignored) { }
    }

    private static void recycle(Bitmap bitmap) {
        if (bitmap != null && !bitmap.isRecycled()) bitmap.recycle();
    }
}
