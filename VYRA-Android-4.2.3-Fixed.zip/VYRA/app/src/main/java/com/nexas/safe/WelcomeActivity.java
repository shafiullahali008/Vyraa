package com.nexas.safe;

import android.animation.ValueAnimator;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.graphics.drawable.GradientDrawable;
import android.graphics.Typeface;

public class WelcomeActivity extends Activity {
    private int stage = 0;
    private LinearLayout content;
    private WelcomeArtwork artwork;
    private TextView[] dots = new TextView[3];
    private Button primary;

    private final String[] titles = {
            "Make room for\nwhat matters.",
            "Build a rhythm\nthat feels yours.",
            "Progress, with\nless pressure."
    };
    private final String[] descriptions = {
            "VYRA brings your focus tools together in a calmer, more considered space.",
            "Create a focus session, choose the apps you want to limit, and set reminders that fit your day.",
            "Track completed sessions, celebrate steady habits, and keep control of your device settings."
    };
    private final String[] labels = {"A calmer start", "Your focus, your rules", "Small steps count"};

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(7, 10, 19));
        getWindow().setNavigationBarColor(Color.rgb(7, 10, 19));
        getWindow().getDecorView().setSystemUiVisibility(0);
        buildScreen();
    }

    private void buildScreen() {
        FrameLayout frame = new FrameLayout(this);
        frame.setBackgroundColor(Color.rgb(7, 10, 19));

        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(24), dp(18), dp(24), dp(22));
        frame.addView(page, new FrameLayout.LayoutParams(-1, -1));

        LinearLayout brand = new LinearLayout(this);
        brand.setGravity(Gravity.CENTER_VERTICAL);
        android.widget.ImageView mark = new android.widget.ImageView(this);
        mark.setImageResource(R.drawable.vyra_3d_icon);
        mark.setScaleType(android.widget.ImageView.ScaleType.CENTER_CROP);
        mark.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{Color.rgb(19, 38, 62), Color.rgb(45, 30, 79)}));
        mark.setClipToOutline(true);
        mark.setElevation(dp(9));
        LinearLayout.LayoutParams mp = new LinearLayout.LayoutParams(dp(48), dp(48));
        mp.rightMargin = dp(11);
        brand.addView(mark, mp);
        LinearLayout brandTexts = new LinearLayout(this);
        brandTexts.setOrientation(LinearLayout.VERTICAL);
        TextView name = label("VYRA", 14, Color.rgb(239, 245, 255), true);
        name.setLetterSpacing(.09f);
        brandTexts.addView(name);
        TextView descriptor = label("A CALMER DIGITAL LIFE", 8, Color.rgb(151, 169, 198), true);
        descriptor.setLetterSpacing(.15f);
        LinearLayout.LayoutParams descriptorLp = new LinearLayout.LayoutParams(-2, -2);
        descriptorLp.topMargin = dp(3);
        brandTexts.addView(descriptor, descriptorLp);
        brand.addView(brandTexts);
        page.addView(brand);

        FrameLayout heroArt = new FrameLayout(this);
        artwork = new WelcomeArtwork(this);
        heroArt.addView(artwork, new FrameLayout.LayoutParams(-1, -1));
        android.widget.ImageView wordmark = new android.widget.ImageView(this);
        wordmark.setImageResource(R.drawable.vyra_3d_wordmark);
        wordmark.setScaleType(android.widget.ImageView.ScaleType.FIT_CENTER);
        wordmark.setAdjustViewBounds(true);
        wordmark.setElevation(dp(12));
        FrameLayout.LayoutParams wordmarkLp = new FrameLayout.LayoutParams(-1, -1, Gravity.CENTER);
        wordmarkLp.leftMargin = dp(4); wordmarkLp.rightMargin = dp(4);
        heroArt.addView(wordmark, wordmarkLp);
        wordmark.setAlpha(0f); wordmark.setScaleX(.94f); wordmark.setScaleY(.94f);
        wordmark.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(850)
                .setInterpolator(new android.view.animation.OvershootInterpolator(.75f)).start();
        LinearLayout.LayoutParams artLp = new LinearLayout.LayoutParams(-1, 0, 1.12f);
        artLp.topMargin = dp(13);
        artLp.bottomMargin = dp(6);
        page.addView(heroArt, artLp);

        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(2), dp(8), dp(2), dp(2));
        page.addView(content, new LinearLayout.LayoutParams(-1, 0, .94f));

        TextView skip = label("SKIP INTRO", 9, Color.rgb(151, 169, 198), true);
        skip.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        page.addView(skip, new LinearLayout.LayoutParams(-1, dp(30)));
        skip.setOnClickListener(v -> finishOnboarding());

        setContentView(frame);
        renderStage();
    }

    private void renderStage() {
        content.removeAllViews();
        artwork.setStage(stage);
        TextView eyebrow = label(labels[stage].toUpperCase(), 9, Color.rgb(90, 239, 213), true);
        eyebrow.setLetterSpacing(.16f);
        content.addView(eyebrow);
        TextView heading = label(titles[stage], 34, Color.rgb(239, 245, 255), true);
        heading.setTypeface(Typeface.create("serif", Typeface.BOLD));
        heading.setLineSpacing(dp(1), 1f);
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(-1, -2);
        hp.topMargin = dp(9);
        content.addView(heading, hp);
        TextView body = label(descriptions[stage], 13, Color.rgb(151, 169, 198), false);
        body.setLineSpacing(dp(4), 1.05f);
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, -2);
        bp.topMargin = dp(12);
        content.addView(body, bp);

        LinearLayout progress = new LinearLayout(this);
        progress.setGravity(Gravity.CENTER_VERTICAL);
        for (int i = 0; i < 3; i++) {
            TextView dot = label(i == stage ? "●" : "○", 13, i == stage ? Color.rgb(90, 239, 213) : Color.rgb(63, 82, 112), true);
            LinearLayout.LayoutParams dlp = new LinearLayout.LayoutParams(-2, -2);
            dlp.rightMargin = dp(8);
            progress.addView(dot, dlp);
            dots[i] = dot;
        }
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(-1, -2);
        pp.topMargin = dp(17);
        content.addView(progress, pp);

        primary = new Button(this);
        primary.setText(stage == 2 ? "ENTER VYRA" : "CONTINUE");
        primary.setTextColor(Color.rgb(7, 10, 19));
        primary.setTextSize(12);
        primary.setAllCaps(false);
        primary.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        GradientDrawable buttonBg = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                new int[]{Color.rgb(90, 239, 213), Color.rgb(161, 133, 255)});
        buttonBg.setCornerRadius(dp(17));
        primary.setBackground(buttonBg);
        primary.setElevation(dp(4));
        LinearLayout.LayoutParams btnp = new LinearLayout.LayoutParams(-1, dp(54));
        btnp.topMargin = dp(18);
        content.addView(primary, btnp);
        primary.setOnClickListener(v -> {
            v.performHapticFeedback(android.view.HapticFeedbackConstants.VIRTUAL_KEY);
            if (stage < 2) {
                stage++;
                renderStage();
            } else finishOnboarding();
        });
        content.setAlpha(0f);
        content.setTranslationY(dp(12));
        content.animate().alpha(1f).translationY(0f).setDuration(380)
                .setInterpolator(new AccelerateDecelerateInterpolator()).start();
    }

    private void finishOnboarding() {
        getSharedPreferences("nexas_welcome", MODE_PRIVATE).edit().putBoolean("complete", true).apply();
        startActivity(new Intent(this, MainActivity.class));
        finish();
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
    }

    private TextView label(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private int dp(int value) { return Math.round(value * getResources().getDisplayMetrics().density); }

    private static final class WelcomeArtwork extends View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF oval = new RectF();
        private float rotation = 0f;
        private int stage = 0;
        private ValueAnimator animator;

        WelcomeArtwork(Activity context) {
            super(context);
            setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        }

        void setStage(int stage) { this.stage = stage; invalidate(); }

        @Override protected void onAttachedToWindow() {
            super.onAttachedToWindow();
            animator = ValueAnimator.ofFloat(0f, 360f);
            animator.setDuration(18000L);
            animator.setRepeatCount(ValueAnimator.INFINITE);
            animator.setInterpolator(new android.view.animation.LinearInterpolator());
            animator.addUpdateListener(a -> { rotation = (float) a.getAnimatedValue(); invalidate(); });
            animator.start();
        }

        @Override protected void onDetachedFromWindow() {
            if (animator != null) animator.cancel();
            super.onDetachedFromWindow();
        }

        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float w = getWidth();
            float h = getHeight();
            float cx = w * .5f;
            float cy = h * .49f;
            float scale = Math.min(w, h) * .37f;

            paint.setShader(new RadialGradient(cx, cy, scale * 1.9f,
                    new int[]{Color.argb(85, 107, 221, 194), Color.argb(24, 139, 143, 235), Color.TRANSPARENT},
                    null, Shader.TileMode.CLAMP));
            canvas.drawCircle(cx, cy, scale * 1.9f, paint);
            paint.setShader(null);

            // Floating perspective planes create a soft 3D orbital composition.
            canvas.save();
            canvas.rotate(rotation * .46f + stage * 21f, cx, cy);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(Math.max(1f, scale * .022f));
            paint.setColor(Color.argb(130, 104, 172, 193));
            oval.set(cx - scale * 1.43f, cy - scale * .48f, cx + scale * 1.43f, cy + scale * .48f);
            canvas.drawOval(oval, paint);
            paint.setColor(Color.argb(95, 127, 121, 207));
            oval.set(cx - scale * 1.23f, cy - scale * .68f, cx + scale * 1.23f, cy + scale * .68f);
            canvas.save();
            canvas.rotate(58f, cx, cy);
            canvas.drawOval(oval, paint);
            canvas.restore();
            paint.setStyle(Paint.Style.FILL);
            canvas.restore();

            float orb = scale * (stage == 1 ? .76f : .83f);
            paint.setShader(new RadialGradient(cx - orb * .32f, cy - orb * .39f, orb * 1.55f,
                    new int[]{Color.rgb(90, 239, 213), Color.rgb(95, 177, 220), Color.rgb(161, 133, 255), Color.rgb(238, 190, 255)},
                    new float[]{0f, .28f, .68f, 1f}, Shader.TileMode.CLAMP));
            canvas.drawCircle(cx, cy, orb, paint);
            paint.setShader(null);

            // Curved specular ribbon and highlight add depth without an external 3D engine.
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeCap(Paint.Cap.ROUND);
            paint.setStrokeWidth(scale * .095f);
            paint.setColor(Color.argb(80, 255, 255, 255));
            oval.set(cx - orb * .82f, cy - orb * .43f, cx + orb * .82f, cy + orb * .50f);
            canvas.save();
            canvas.rotate(-24f + (float)Math.sin(Math.toRadians(rotation)) * 6f, cx, cy);
            canvas.drawArc(oval, 205f, 138f, false, paint);
            canvas.restore();
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(Color.argb(210, 255, 255, 255));
            canvas.drawCircle(cx - orb * .34f, cy - orb * .43f, orb * .10f, paint);

            // Satellite particles orbit the central glass-like sphere.
            for (int i = 0; i < 8; i++) {
                double a = Math.toRadians(rotation + i * 45d + stage * 17d);
                float rx = (float)Math.cos(a) * scale * 1.34f;
                float ry = (float)Math.sin(a) * scale * .72f;
                paint.setColor(i % 2 == 0 ? Color.rgb(90, 239, 213) : Color.rgb(161, 133, 255));
                canvas.drawCircle(cx + rx, cy + ry, scale * (i % 3 == 0 ? .055f : .032f), paint);
            }

            paint.setColor(Color.argb(42, 88, 112, 150));
            canvas.drawOval(cx - scale * .86f, cy + scale * .91f, cx + scale * .86f, cy + scale * 1.12f, paint);
        }
    }
}
