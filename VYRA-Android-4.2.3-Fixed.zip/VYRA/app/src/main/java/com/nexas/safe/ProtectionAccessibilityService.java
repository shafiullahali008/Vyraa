package com.nexas.safe;

import android.accessibilityservice.AccessibilityService;
import android.content.Intent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.IntentFilter;
import android.os.Build;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import java.util.Locale;
import java.util.Set;

/** User-enabled accessibility service for selected-app focus rules and local page-text checks. */
public class ProtectionAccessibilityService extends AccessibilityService {
    private static final long MIN_SCAN_INTERVAL_MS = 850L;
    private static final int MAX_TEXT_CHARS = 7000;
    private static final int MAX_VISITED_NODES = 600;
    private long lastTextScanAt;
    private String lastScannedPackage = "";
    private String lastCurrentPackage = "";
    private int lastTextHash;
    private long lastBlockAt;
    private boolean visualReceiverRegistered;
    private final BroadcastReceiver visualReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            if (intent == null || !VisualScreenProtectionService.ACTION_VISUAL_DETECTED.equals(intent.getAction())) return;
            // showBlockScreen owns the shared cooldown timestamp. Do not set it here,
            // or the immediately following call would suppress its own block screen.
            performGlobalAction(GLOBAL_ACTION_HOME);
            showBlockScreen("visual");
        }
    };

    @Override protected void onServiceConnected() {
        super.onServiceConnected();
        IntentFilter filter = new IntentFilter(VisualScreenProtectionService.ACTION_VISUAL_DETECTED);
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(visualReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
        else registerReceiver(visualReceiver, filter);
        visualReceiverRegistered = true;
    }

    @Override public void onDestroy() {
        if (visualReceiverRegistered) {
            try { unregisterReceiver(visualReceiver); } catch (Exception ignored) { }
            visualReceiverRegistered = false;
        }
        super.onDestroy();
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null || event.getPackageName() == null) return;
        String packageName = event.getPackageName().toString();
        if (!packageName.equals(lastCurrentPackage)) {
            lastCurrentPackage = packageName;
            ProtectionPrefs.prefs(this).edit().putString(ProtectionPrefs.KEY_CURRENT_PACKAGE, packageName).apply();
        }
        if (packageName.equals(getPackageName()) || packageName.equals("com.android.systemui")) return;

        if (ProtectionPrefs.isFocusActive(this)
                && ProtectionPrefs.blockedPackages(this).contains(packageName.toLowerCase(Locale.ROOT))) {
            performGlobalAction(GLOBAL_ACTION_HOME);
            showBlockScreen("focus");
            return;
        }

        if (!ProtectionPrefs.keywordProtectionEnabled(this)) return;
        int type = event.getEventType();
        if (type != AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED
                && type != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED
                && type != AccessibilityEvent.TYPE_VIEW_SCROLLED) return;

        long now = android.os.SystemClock.uptimeMillis();
        boolean packageChanged = !packageName.equals(lastScannedPackage);
        if (!packageChanged && now - lastTextScanAt < MIN_SCAN_INTERVAL_MS) return;
        lastScannedPackage = packageName;
        lastTextScanAt = now;

        StringBuilder pageText = new StringBuilder(1024);
        for (CharSequence text : event.getText()) appendText(pageText, text);
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root != null) {
            try { collectVisibleText(root, 0, pageText, new int[]{MAX_VISITED_NODES}); }
            finally { root.recycle(); }
        }
        if (pageText.length() == 0) return;
        int textHash = pageText.toString().hashCode();
        if (textHash == lastTextHash && !packageChanged) return;
        lastTextHash = textHash;
        Set<String> customKeywords = ProtectionPrefs.keywords(this);
        if (ContextAwareTextClassifier.shouldBlock(pageText.toString(), customKeywords)) {
            showBlockScreen("keyword");
        }
    }

    private void collectVisibleText(AccessibilityNodeInfo node, int depth, StringBuilder out, int[] remainingNodes) {
        if (node == null || depth > 18 || out.length() >= MAX_TEXT_CHARS || remainingNodes[0] <= 0) return;
        remainingNodes[0]--;
        appendText(out, node.getText());
        appendText(out, node.getContentDescription());
        int count = Math.min(node.getChildCount(), 55);
        for (int i = 0; i < count && out.length() < MAX_TEXT_CHARS; i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) {
                try { collectVisibleText(child, depth + 1, out, remainingNodes); }
                finally { child.recycle(); }
            }
        }
    }

    private void appendText(StringBuilder out, CharSequence value) {
        if (value == null || out.length() >= MAX_TEXT_CHARS) return;
        String text = value.toString().trim();
        if (text.isEmpty()) return;
        if (out.length() > 0) out.append(' ');
        int remaining = MAX_TEXT_CHARS - out.length();
        out.append(text, 0, Math.min(text.length(), remaining));
    }

    private void showBlockScreen(String reason) {
        long now = android.os.SystemClock.uptimeMillis();
        if (lastBlockAt != 0L && now - lastBlockAt < 2200L) return;
        lastBlockAt = now;
        Intent intent = new Intent(this, BlockActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        intent.putExtra("reason", reason);
        startActivity(intent);
    }

    @Override public void onInterrupt() { }
}
