package com.nexas.safe;

import android.content.Context;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Downloads a locally-run detector model only after the user taps Install AI model. */
final class ModelManager {
    // Public model artifact; the model's separate AGPL-3.0 license and attribution are in MODEL-LICENSE.md.
    static final String MODEL_URL = "https://huggingface.co/enaser/blurguard-models/resolve/main/nudenet_320n_640_fp16.tflite";
    static final String MODEL_NAME = "nudenet_320n_640_fp16.tflite";
    private static final long MIN_SIZE = 5_000_000L;
    private static final long MAX_SIZE = 8_000_000L;
    private static final ExecutorService EXECUTOR = Executors.newSingleThreadExecutor();

    interface Callback {
        void onProgress(int percent);
        void onComplete(boolean success, String message);
    }

    private ModelManager() { }

    static File modelFile(Context context) {
        File dir = new File(context.getNoBackupFilesDir(), "models");
        if (!dir.exists() && !dir.mkdirs() && !dir.isDirectory()) {
            throw new IllegalStateException("Could not create the local model directory");
        }
        return new File(dir, MODEL_NAME);
    }

    static boolean isReady(Context context) {
        File file = modelFile(context);
        return file.isFile() && file.length() >= MIN_SIZE && hasTfliteHeader(file);
    }

    static void download(Context context, Callback callback) {
        Context app = context.getApplicationContext();
        EXECUTOR.execute(() -> {
            File target = null;
            File temp = null;
            HttpURLConnection connection = null;
            try {
                target = modelFile(app);
                temp = new File(target.getParentFile(), MODEL_NAME + ".download");
                connection = (HttpURLConnection) new URL(MODEL_URL).openConnection();
                connection.setConnectTimeout(20000);
                connection.setReadTimeout(45000);
                connection.setInstanceFollowRedirects(true);
                connection.setUseCaches(false);
                connection.setRequestProperty("Accept", "application/octet-stream");
                connection.setRequestProperty("User-Agent", "VYRA-Android/4.2.3");
                connection.connect();
                int code = connection.getResponseCode();
                if (code < 200 || code >= 300) throw new IllegalStateException("Model server returned HTTP " + code);
                long total = connection.getContentLengthLong();
                if (total > MAX_SIZE || (total > 0 && total < MIN_SIZE)) {
                    throw new IllegalStateException("Unexpected model download size");
                }
                long count = 0;
                try (InputStream in = connection.getInputStream(); FileOutputStream out = new FileOutputStream(temp)) {
                    byte[] buffer = new byte[64 * 1024];
                    int read;
                    while ((read = in.read(buffer)) != -1) {
                        count += read;
                        if (count > MAX_SIZE) throw new IllegalStateException("Unexpected model size; download cancelled");
                        out.write(buffer, 0, read);
                        if (total > 0) {
                            int pct = (int) Math.min(99, (count * 100L) / total);
                            callback.onProgress(pct);
                        }
                    }
                    out.flush();
                }
                if (count < MIN_SIZE || !hasTfliteHeader(temp)) {
                    throw new IllegalStateException("Downloaded file is incomplete or is not a TFLite model");
                }
                // Replace only after the new file has passed basic validation. The temp file
                // is in the same directory, so this is normally a same-filesystem rename.
                try {
                    Files.move(temp.toPath(), target.toPath(), StandardCopyOption.ATOMIC_MOVE,
                            StandardCopyOption.REPLACE_EXISTING);
                } catch (java.nio.file.AtomicMoveNotSupportedException ex) {
                    Files.move(temp.toPath(), target.toPath(), StandardCopyOption.REPLACE_EXISTING);
                }
                callback.onProgress(100);
                callback.onComplete(true, "On-device AI model installed.");
            } catch (Exception ex) {
                if (temp != null && temp.exists()) temp.delete();
                callback.onComplete(false, ex.getMessage() == null ? "Model download failed" : ex.getMessage());
            } finally {
                if (connection != null) connection.disconnect();
            }
        });
    }

    private static boolean hasTfliteHeader(File file) {
        try (InputStream in = new java.io.FileInputStream(file)) {
            byte[] header = new byte[8];
            if (in.read(header) != 8) return false;
            return new String(header, 4, 4, StandardCharsets.US_ASCII).equals("TFL3");
        } catch (Exception ignored) {
            return false;
        }
    }
}
