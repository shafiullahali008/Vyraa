# VYRA 3D identity

Primary identity: metallic chrome shield with a sculpted V monogram, cyan edge lighting and restrained violet accents on a deep navy background.

Files:
- `VYRA-3D-Wordmark.png`: onboarding and promotional wordmark artwork.
- `VYRA-3D-App-Icon.png`: square launcher emblem crop.

The Android adaptive launcher icon uses the emblem crop. App UI brand mark uses the same emblem.
