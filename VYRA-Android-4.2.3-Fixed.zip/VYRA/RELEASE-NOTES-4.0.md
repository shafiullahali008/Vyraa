# VYRA 4.0.0

## Branding
- App name changed to VYRA.
- Added new shield/V launcher icon and updated onboarding, dashboard, block screen and notification labels.
- Kept `applicationId` and Java package path stable to preserve update compatibility.

## Focus
- Added a long-term Focus Journey with a durable timestamp.
- Added an indefinite selected-app protection state alongside existing timed sessions.
- Corrected Strict Mode early-exit timing so the full 30-second wait is enforced before the confirmation step.

## Protection and privacy
- Removed screen recording / MediaProjection service integration and permissions.
- Background accessibility page-text checks now scan a bounded amount of page text at a throttled interval and respond to window / scroll updates.
- Replaced raw substring blocking with context-aware signals and educational / news / health / legal context checks.
- Clarified that the classifier is a best-effort heuristic, not a perfect AI model.

## Offline guide and arcade
- Added VYRA Offline Guide, a local rule-based helper (not an LLM).
- Retained two OpenGL ES 2.0 arcade prototypes (runner and rolling-orb course) and existing brain-training mini-games.

## Verification still required
- Full Gradle Android build, emulator run, physical-device tests, accessibility compatibility checks across browsers and GPU performance profiling.
