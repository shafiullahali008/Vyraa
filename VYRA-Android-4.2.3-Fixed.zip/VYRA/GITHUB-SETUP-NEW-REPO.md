# Build VYRA 4.2.3 in GitHub Actions

1. Upload `VYRA-Android-4.2.3-Full-Audit-Fix.zip` to the repository root.
2. Create `.github/workflows/vyra-android-build.yml` using the supplied workflow file.
3. Remove or disable older duplicate VYRA Android workflows.
4. Commit both files to the `main` branch.
5. Open Actions and run **VYRA Android Build**.
6. Download `VYRA-Android-APK` if APK assembly succeeds.
7. If the run fails, download `VYRA-Build-Logs` for the actual Gradle output.

The workflow provisions JDK 17, Android SDK command-line tools, Android Platform 35, Build Tools 35.0.0, and Gradle 8.9. The ZIP is extracted before the Gradle setup action so that it can find the Gradle project. Android SDK package names are installed as separate arguments rather than a multiline `packages` input.

## Verification note

Static source checks and the pure-Java classifier tests passed. A full Android APK build and physical-device test have not been run in this environment; the GitHub Actions run is required to confirm Android resource linking, dexing and APK packaging.
