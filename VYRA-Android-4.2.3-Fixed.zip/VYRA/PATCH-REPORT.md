# VYRA 4.2.3 — Patch report

Date: 2026-11-25

## Confirmed build failure

The uploaded ZIP's Git blob SHA-1 matches the ZIP stored in `shafiullahali008/Vyraa` (`a10a402044e4c0dd5d0cb8deda1c3f6331bd7658`). The GitHub Actions job `139055111313` completed JDK setup, Android SDK setup, source ZIP verification/extraction, Gradle setup, Gradle project configuration, dependency resolution, Android resource processing and duplicate-class checks. It failed at `:app:compileDebugJavaWithJavac` with 10 diagnostics from four incorrect Java statements.

## Source fixes applied

File: `app/src/main/java/com/nexas/safe/MainActivity.java`

- The visual scan status layout variable at the former line 512 now uses `LinearLayout.LayoutParams`.
- The visual scan button layout variable at the former line 514 now uses `LinearLayout.LayoutParams`.
- The visual privacy text layout variable at the former line 517 now uses `LinearLayout.LayoutParams`.
- The helpers `fullWrap()` and `fullWidth()` were inspected; both return `LinearLayout.LayoutParams`, so their returned values are assigned directly without unnecessary constructors.
- The inactive journey calculation now uses `start.plus(java.time.Duration.ofMillis(savedDuration))`. `savedDuration` is a `long` elapsed-millisecond value persisted by the journey-ending code.

## CI workflow corrections

Reference workflow: `ci/vyra-android-build.yml`

- Added an extraction check for `MainActivity.java`.
- Retained the explicit Gradle 8.9 installation through `gradle/actions/setup-gradle` because this source package does not include a Gradle wrapper. The build invokes the installed `gradle` command.
- Preserved SDK package installation as separate `sdkmanager --install` calls.
- Retained extraction before Gradle setup.
- Unit-test failures do not prevent uploading an APK that assembled successfully, but an explicit final gate now makes the overall workflow fail when the unit tests fail.
- Build and test output logs are uploaded for diagnosis.

The existing GitHub workflow was separately inspected. Its test step had `continue-on-error: true` without an explicit final failure gate. Replace the repository workflow at `.github/workflows/vyra-android-build.yml` with the supplied standalone workflow file to apply the CI correction. This package does not modify the remote repository.

## Build configuration review

The existing configuration is retained:

- Android Gradle Plugin: 8.7.3
- Gradle: 8.9
- JDK: 17
- compileSdk / targetSdk: 35
- minSdk: 26

Gradle 8.9 is the minimum version required by Android Gradle Plugin 8.7. The latest failed job reached Java compilation with this combination, so the compile failure was not caused by an AGP/Gradle/JDK mismatch. The latest job did not fail with HTTP 429; dependency resolution completed before Java compilation. Earlier HTTP 429 reports are a separate historical incident.

No Gradle wrapper JAR or wrapper scripts are included in this source package by design. The supplied workflow provisions Gradle 8.9 directly and uses `gradle`, not `./gradlew`.

## Checks performed on the patched package

- Original ZIP CRC check: passed.
- Repacked ZIP CRC check and top-level `VYRA/` structure: passed.
- Java 17 grammar parse: all 16 Java source/test files parsed with no syntax diagnostics.
- Android XML parse: all 11 XML files parsed.
- Manifest component-to-source class checks: passed.
- Local Android resource reference scan: passed (Android framework references excluded).
- Eight pure-Java classifier test cases: passed in a local `javac`/`java` harness.
- `ZonedDateTime.plus(Duration.ofMillis(long))` compile/runtime check: passed.
- Workflow YAML parse and all seven embedded Bash syntax checks: passed.
- Assertions confirm all four reported source errors were corrected and both layout helper return types were checked.

## Not verified

This environment has no installed Gradle distribution or Android SDK, and outbound package downloads are unavailable. Therefore, the patched package has **not** been run through `assembleDebug`, Android resource linking, D8, APK packaging, or a fresh GitHub Actions run. No APK is included or claimed as built. Replace the repository ZIP and workflow, run the action, and inspect the resulting APK artifact and test result before release.
