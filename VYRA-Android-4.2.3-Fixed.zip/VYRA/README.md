# VYRA 4.2.3 — 3D Identity, Visual Protection & Full Source Audit

VYRA is an Android digital-wellbeing project built around timed focus, a persistent long-term Focus Journey, selected-app restrictions, local page-text heuristics, optional user-selected image checks, reminders, offline games and an offline help guide.

## Identity
- App label: **VYRA**
- Launcher mark: generated 3D chrome shield + V emblem with cyan / violet edge lighting
- Android application ID remains `com.nexas.safe` so an existing install can receive an in-place update without changing its package identity. Internal Java package names and persisted preference keys are also retained for compatibility.

## Live visual protection setup

1. Install the on-device model from Smart Protection.
2. Enable VYRA Accessibility in Android Settings so a detection can trigger the Home action and block screen.
3. Tap **Enable live image protection**. Android presents its native screen-capture consent prompt; the user must approve it.
4. When approved, the foreground service starts and shows an ongoing notification with **Stop protection**.
5. To stop, use the notification action or Android's own screen-sharing controls. The session does not silently restart after reboot or process death; Android requires fresh consent for a new MediaProjection session.

The scan interval is near 0.5 seconds as a target, not a hard real-time guarantee. Inference time, device load, secure app windows and Android scheduling affect latency. The classifier can produce false positives and false negatives.

## Build

- Android Gradle Plugin: 8.7.3
- Gradle: 8.9
- JDK: 17
- compileSdk / targetSdk: 35
- minSdk: 26

The supplied GitHub Actions workflow provisions Gradle 8.9, JDK 17 and Android SDK Platform 35 / Build Tools 35.0.0. It uses the installed Gradle command provided by `gradle/actions/setup-gradle`; this source archive intentionally does not include a Gradle wrapper JAR or `gradlew` scripts. Upload `VYRA-Android-4.2.3-Full-Audit-Fix.zip` to the repository root and replace the repository workflow at `.github/workflows/vyra-android-build.yml` with the updated `ci/vyra-android-build.yml` from this package. APK assembly and unit tests are separate: the APK is uploaded after successful assembly, and a unit-test failure then marks the workflow failed. Assembly/test logs are uploaded for diagnosis.

## 4.2.3 source-audit fixes

- Corrected the Android SDK workflow so `setup-android` receives a single package value and remaining SDK packages are installed as separate `sdkmanager --install` arguments.
- Extracts the source archive before the Gradle setup action runs.
- Separates APK assembly and unit tests, and uploads diagnostic logs.
- Fixes visual-block cooldown, stride-aware captured-frame copying, visual-service permission revocation handling and capture memory limits.
- Reuses classifier buffers and validates the model tensor layout; allocation failures close the interpreter cleanly.
- Includes the exposed male-chest class in the visual screen-filter signal set, alongside the other configured exposed-content classes.
- Downsamples user-selected block-screen images asynchronously to reduce main-thread stalls and large-bitmap memory spikes.
- Hardens model-file replacement and adds explicit MediaProjection service-start error handling.
- Fixes Arcade GL-thread state visibility and lifecycle cleanup.

## What changed in 4.0

- Rebranded visible app surfaces, onboarding, block screen, notifications and launcher artwork to VYRA.
- Added an open-ended Focus Journey with persisted start time and calendar-based years / months / days / hh:mm:ss display.
- Focus Journey can keep selected-app restrictions active without an automatic expiry. The user can end it from the Focus screen; Strict Mode adds a deliberate 30-second early-exit pause.
- Added an optional MediaProjection visual-protection session. Android must display its screen-capture consent prompt before every new session. A persistent foreground notification exposes a Stop action. Frames are checked in memory on-device and are not saved or uploaded.
- Replaced direct substring keyword blocking with page-level signal scoring, high-confidence phrase matching, contextual exemptions and an 850 ms scan throttle. Traversal is capped at 600 accessibility nodes / 7,000 characters and identical page text is skipped. This reduces, but cannot eliminate, false positives and false negatives.
- Added VYRA Offline Guide. It is rule-based and runs locally; it is not a generative language model.
- Kept two offline OpenGL ES 2.0 playable prototypes: Temple Sprint 3D and Orbit Roll 3D. Both use procedural geometry and touch-swipe controls; they are not production-scale 4K games or a commercial game-engine build.

## Limits and safety

- Accessibility scanning only sees text and app events exposed by supported Android apps. Some browsers, pages, custom views, images and videos expose little or no text.
- The text classifier is a lightweight heuristic, not a certified AI content classifier. It can miss content and may still flag some pages incorrectly.
- Live visual classification requires the model to be installed, VYRA Accessibility enabled for exit/block actions, and the user to approve Android screen capture each session. Android system indicators and the persistent VYRA notification remain visible. Frames are transient in-memory data only; no recording file is created and nothing is uploaded. Capture can be stopped from Android system controls or the VYRA notification.
- A normal Android application cannot make itself undeletable. Optional Device Admin may add a removal step, but Android system recovery and uninstall controls remain available.
- A true offline generative AI assistant requires properly licensed model weights, memory/performance profiling and device testing. The included VYRA Offline Guide uses local scripted intent matching.
- “4K” refers to rendered output only when the device display and GPU support it. These current games are 3D prototypes rather than production-scale 4K titles.

## Privacy

Page-text checks run locally through the Accessibility permission after the user enables it. No page text is uploaded by the checker. The optional visual test reads an image the user chooses and does not upload it. Live visual protection processes transient screen frames locally after a separate Android MediaProjection consent prompt and displays an ongoing notification with a Stop action.

The About page uses a bundled creator-profile image (`profile_shafi.webp`). Because the GitHub repository is public, that image is publicly downloadable and will also be included in the built APK. Replace or remove it before public distribution if it is not intended to be public.
