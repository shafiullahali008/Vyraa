# Third-party on-device model notice

VYRA can download `nudenet_320n_640_fp16.tflite` from the `enaser/blurguard-models` Hugging Face repository only after the user chooses **Install AI Model**. The model binary is not included in this source archive.

- Model: `nudenet_320n_640_fp16.tflite`
- Upstream: https://huggingface.co/enaser/blurguard-models
- Model license: AGPL-3.0, as identified by the upstream repository for this specific model file.
- Upstream model card documents a float32 NHWC input tensor `[1,640,640,3]` and a float32 output tensor `[1,22,8400]` for this 18-class NudeNet detector.

The app checks basic file size and the TensorFlow Lite file header at download time, then validates tensor count, dimensions and data types when opening the model. It does not currently pin a SHA-256 checksum; a valid TFLite header and matching tensor shape are not a cryptographic authenticity guarantee.

Before redistributing an application that downloads or uses this model, review the complete AGPL-3.0 license and attribution obligations with an appropriate legal reviewer. Do not assume that the app's own source license automatically covers third-party model weights.
