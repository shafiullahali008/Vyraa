# Third-party notices

- TensorFlow Lite Android runtime: `org.tensorflow:tensorflow-lite:2.17.0`. See https://github.com/tensorflow/tensorflow and its applicable license.
- Optional visual detector: `nudenet_320n_640_fp16.tflite`, downloaded at runtime from https://huggingface.co/enaser/blurguard-models. The upstream repository identifies this model file as AGPL-3.0. See `MODEL-LICENSE.md`.
- Android platform APIs, command-line tools and SDK packages are subject to their respective Android/Google terms.

The model is not bundled in this source ZIP. It is downloaded only after the user initiates model installation.
